//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by SuDoku.rc
//
#define IDD_DIALOG1                     101
#define IDD_DIALOG                      101
#define IDR_MENU                        104
#define IDC_RUN                         1001
#define IDC_BOARD                       1002
#define IDC_PROGRESS                    1003
#define IDC_GENERATION                  1004
#define IDC_RESET                       1005
#define IDC_CLEAR                       1006
#define IDC_RUN2                        1007
#define IDC_BOX                         1009
#define IDC_UPDATE                      1010
#define IDC_ROW                         1011
#define IDC_COLUMN                      1012
#define IDC_SHOW                        1013
#define IDC_1                           1015
#define IDC_2                           1016
#define IDC_3                           1017
#define IDC_4                           1018
#define IDC_5                           1019
#define IDC_6                           1020
#define IDC_7                           1021
#define IDC_8                           1022
#define IDC_9                           1023
#define IDC_OFF                         1024
#define IDC_0                           1024
#define IDM_FILE_NEW                    40019
#define IDM_FILE_LOAD                   40020
#define IDM_FILE_SAVE                   40021
#define IDM_FILE_EXIT                   40022
#define IDM_HELP_ABOUT                  40023

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40024
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
